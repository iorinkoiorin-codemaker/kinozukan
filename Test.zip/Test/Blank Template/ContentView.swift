import SwiftUI

struct ContentView: View {
    @AppStorage("darkMode") private var darkMode = false

    var body: some View {
        NavigationView {
            List {
                Section(header: Text("入力部品")) {
                    NavigationLink(destination: ButtonLab()) {
                        Label("Button - ボタン", systemImage: "hand.tap")
                    }

                    NavigationLink(destination: ToggleLab()) {
                        Label("Toggle - スイッチ", systemImage: "switch.2")
                    }

                    NavigationLink(destination: SliderLab()) {
                        Label("Slider - スライダー", systemImage: "slider.horizontal.3")
                    }

                    NavigationLink(destination: TextFieldLab()) {
                        Label("TextField - 文字入力", systemImage: "text.cursor")
                    }

                    NavigationLink(destination: PickerLab()) {
                        Label("Picker - 選択メニュー", systemImage: "list.bullet")
                    }

                    NavigationLink(destination: StepperLab()) {
                        Label("Stepper - 数値変更", systemImage: "plusminus")
                    }

                    NavigationLink(destination: DatePickerLab()) {
                        Label("DatePicker - 日付選択", systemImage: "calendar")
                    }

                    NavigationLink(destination: ColorPickerLab()) {
                        Label("ColorPicker - 色選択", systemImage: "paintpalette")
                    }
                }

                Section(header: Text("表示部品")) {
                    NavigationLink(destination: ProgressLab()) {
                        Label("ProgressView - 進捗表示", systemImage: "chart.bar")
                    }

                    NavigationLink(destination: AlertLab()) {
                        Label("Alert - ダイアログ", systemImage: "exclamationmark.bubble")
                    }

                    NavigationLink(destination: SheetLab()) {
                        Label("Sheet - モーダル画面", systemImage: "rectangle.portrait")
                    }
                }

                Section(header: Text("アプリ")) {
                    NavigationLink(destination: SettingsLab()) {
                        Label("設定", systemImage: "gearshape")
                    }

                    NavigationLink(destination: AboutLab()) {
                        Label("このアプリについて", systemImage: "info.circle")
                    }
                }
            }
            .navigationBarTitle("機能図鑑")
        }
        .navigationViewStyle(.stack)
        .preferredColorScheme(darkMode ? .dark : .light)
    }
}

// MARK: - Button

struct ButtonLab: View {
    @State private var count = 0
    @State private var buttonText = "押してみよう"

    var body: some View {
        List {
            Section(header: Text("Button の実験室")) {
                Button(buttonText) {
                    count += 1
                }

                Text("押した回数：\(count)")

                Button("ボタンの文字を変更") {
                    buttonText = "変更されたボタン！"
                }

                Button("リセット") {
                    count = 0
                    buttonText = "押してみよう"
                }
            }

            Section(header: Text("コード例")) {
                Text("Button(\"実行\") {\n    count += 1\n}")
                    .font(.system(.body, design: .monospaced))
                    .textSelection(.enabled)
            }
        }
        .navigationBarTitle("Button")
    }
}

// MARK: - Toggle

struct ToggleLab: View {
    @State private var enabled = false

    var body: some View {
        List {
            Section(header: Text("Toggle の実験室")) {
                Toggle("スイッチを切り替える", isOn: $enabled)

                Text(enabled ? "現在の状態：オン" : "現在の状態：オフ")
                Text(enabled ? "スイッチは有効です。" : "スイッチは無効です。")
            }

            Section(header: Text("コード例")) {
                Text("@State private var enabled = false\n\nToggle(\"通知\", isOn: $enabled)")
                    .font(.system(.body, design: .monospaced))
                    .textSelection(.enabled)
            }
        }
        .navigationBarTitle("Toggle")
    }
}

// MARK: - Slider

struct SliderLab: View {
    @State private var amount = 50.0

    var body: some View {
        List {
            Section(header: Text("Slider の実験室")) {
                Slider(value: $amount, in: 0...100)

                Text("現在の値：\(Int(amount))")

                ProgressView(value: amount, total: 100)

                Button("50 に戻す") {
                    amount = 50
                }
            }

            Section(header: Text("コード例")) {
                Text("@State private var amount = 50.0\n\nSlider(value: $amount, in: 0...100)")
                    .font(.system(.body, design: .monospaced))
                    .textSelection(.enabled)
            }
        }
        .navigationBarTitle("Slider")
    }
}

// MARK: - TextField

struct TextFieldLab: View {
    @State private var input = ""

    var body: some View {
        List {
            Section(header: Text("TextField の実験室")) {
                TextField("文字を入力してください", text: $input)

                Text("入力した文字：")
                Text(input.isEmpty ? "まだ入力されていません" : input)
                Text("文字数：\(input.count)")

                Button("入力を消去") {
                    input = ""
                }
            }

            Section(header: Text("コード例")) {
                Text("@State private var input = \"\"\n\nTextField(\"入力\", text: $input)")
                    .font(.system(.body, design: .monospaced))
                    .textSelection(.enabled)
            }
        }
        .navigationBarTitle("TextField")
    }
}

// MARK: - Picker

struct PickerLab: View {
    @State private var selectedFruit = "りんご"

    var body: some View {
        List {
            Section(header: Text("Picker の実験室")) {
                Picker("好きな果物", selection: $selectedFruit) {
                    Text("りんご").tag("りんご")
                    Text("バナナ").tag("バナナ")
                    Text("ぶどう").tag("ぶどう")
                    Text("みかん").tag("みかん")
                }
                .pickerStyle(.menu)

                Text("選択中：\(selectedFruit)")
            }

            Section(header: Text("コード例")) {
                Text(
                    "Picker(\"果物\", selection: $selectedFruit) {\n    Text(\"りんご\").tag(\"りんご\")\n    Text(\"バナナ\").tag(\"バナナ\")\n}"
                )
                .font(.system(.body, design: .monospaced))
                .textSelection(.enabled)
            }
        }
        .navigationBarTitle("Picker")
    }
}

// MARK: - Stepper

struct StepperLab: View {
    @State private var number = 1

    var body: some View {
        List {
            Section(header: Text("Stepper の実験室")) {
                Stepper("個数：\(number)", value: $number, in: 0...20)

                Text("現在の数値：\(number)")
                Text("合計金額（1個100円）：\(number * 100)円")

                Button("1 に戻す") {
                    number = 1
                }
            }

            Section(header: Text("コード例")) {
                Text("@State private var number = 1\n\nStepper(\"個数\", value: $number, in: 0...20)")
                    .font(.system(.body, design: .monospaced))
                    .textSelection(.enabled)
            }
        }
        .navigationBarTitle("Stepper")
    }
}

// MARK: - DatePicker

struct DatePickerLab: View {
    @State private var selectedDate = Date()

    var body: some View {
        List {
            Section(header: Text("DatePicker の実験室")) {
                DatePicker(
                    "日付を選ぶ",
                    selection: $selectedDate,
                    displayedComponents: .date
                )

                Text("選択した日付：")
                Text(selectedDate, style: .date)
            }

            Section(header: Text("コード例")) {
                Text("DatePicker(\"日付\", selection: $selectedDate, displayedComponents: .date)")
                    .font(.system(.body, design: .monospaced))
                    .textSelection(.enabled)
            }
        }
        .navigationBarTitle("DatePicker")
    }
}

// MARK: - ColorPicker

struct ColorPickerLab: View {
    @State private var selectedColor = Color.blue

    var body: some View {
        List {
            Section(header: Text("ColorPicker の実験室")) {
                HStack {
                    Spacer()

                    ColorPicker(
                        "色を選んでください",
                        selection: $selectedColor,
                        supportsOpacity: false
                    )
                    .labelsHidden()

                    Spacer()
                }

                Button("青に戻す") {
                    selectedColor = .blue
                }
            }

            Section(header: Text("コード例")) {
                Text(
                    """
                    @State private var selectedColor = Color.blue

                    ColorPicker(
                        "色",
                        selection: $selectedColor,
                        supportsOpacity: false
                    )
                    """
                )
                .font(.system(.body, design: .monospaced))
                .textSelection(.enabled)
            }
        }
        .listStyle(.insetGrouped)
        .navigationBarTitle("ColorPicker")
    }
}

// MARK: - ProgressView

struct ProgressLab: View {
    @State private var progress = 0.3

    var body: some View {
        List {
            Section(header: Text("ProgressView の実験室")) {
                ProgressView(value: progress, total: 1.0)

                Text("進捗：\(Int(progress * 100))%")

                Button("進捗を増やす") {
                    progress = min(progress + 0.1, 1.0)
                }

                Button("進捗を減らす") {
                    progress = max(progress - 0.1, 0.0)
                }

                Button("完了にする") {
                    progress = 1.0
                }

                Button("最初に戻す") {
                    progress = 0.0
                }
            }

            Section(header: Text("コード例")) {
                Text("ProgressView(value: progress, total: 1.0)")
                    .font(.system(.body, design: .monospaced))
                    .textSelection(.enabled)
            }
        }
        .navigationBarTitle("ProgressView")
    }
}

// MARK: - Alert

struct AlertLab: View {
    @State private var showAlert = false

    var body: some View {
        List {
            Section(header: Text("Alert の実験室")) {
                Button("アラートを表示") {
                    showAlert = true
                }

                Text("ボタンを押すとダイアログが表示されます。")
            }

            Section(header: Text("コード例")) {
                Text(
                    ".alert(isPresented: $showAlert) {\n    Alert(\n        title: Text(\"お知らせ\"),\n        message: Text(\"これはサンプルです\"),\n        dismissButton: .default(Text(\"OK\"))\n    )\n}"
                )
                .font(.system(.body, design: .monospaced))
                .textSelection(.enabled)
            }
        }
        .navigationBarTitle("Alert")
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("お知らせ"),
                message: Text("これは機能図鑑のアラートです。"),
                dismissButton: .default(Text("OK"))
            )
        }
    }
}

// MARK: - Sheet

struct SheetLab: View {
    @State private var showSheet = false

    var body: some View {
        List {
            Section(header: Text("Sheet の実験室")) {
                Button("シートを開く") {
                    showSheet = true
                }

                Text("シートは画面の上に重ねて表示されます。")
            }

            Section(header: Text("コード例")) {
                Text(".sheet(isPresented: $showSheet) {\n    SheetContentLab()\n}")
                    .font(.system(.body, design: .monospaced))
                    .textSelection(.enabled)
            }
        }
        .navigationBarTitle("Sheet")
        .sheet(isPresented: $showSheet) {
            SheetContentLab()
        }
    }
}

struct SheetContentLab: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Image(systemName: "rectangle.portrait")
                    .font(.system(size: 50))
                    .foregroundColor(.blue)

                Text("シート画面")
                    .font(.title)

                Text("これは別の画面として重ねて表示されています。")

                Button("閉じる") {
                    presentationMode.wrappedValue.dismiss()
                }
            }
            .padding()
            .navigationBarTitle("サンプルシート", displayMode: .inline)
        }
    }
}

// MARK: - Settings

struct SettingsLab: View {
    @AppStorage("darkMode") private var darkMode = false
    @AppStorage("showTips") private var showTips = true
    @AppStorage("soundEnabled") private var soundEnabled = true

    var body: some View {
        List {
            Section(header: Text("表示")) {
                Toggle("ダークモード", isOn: $darkMode)
                    .toggleStyle(SwitchToggleStyle(tint: .green))

                Text(darkMode ? "選択：ダークモード" : "選択：ライトモード")
                    .foregroundColor(.secondary)
            }

            Section(header: Text("機能")) {
                Toggle("ヒントを表示", isOn: $showTips)
                    .toggleStyle(SwitchToggleStyle(tint: .green))

                Toggle("効果音を有効にする", isOn: $soundEnabled)
                    .toggleStyle(SwitchToggleStyle(tint: .green))
            }

            Section(header: Text("設定について")) {
                Text("ダークモードはアプリ全体に反映されます。ヒントと効果音の設定は保存されます。")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }

            Section(header: Text("リセット")) {
                Button {
                    darkMode = false
                    showTips = true
                    soundEnabled = true
                } label: {
                    Label(
                        "設定を初期状態に戻す",
                        systemImage: "arrow.counterclockwise"
                    )
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationBarTitle("設定")
    }
}

// MARK: - About

struct AboutLab: View {
    var body: some View {
        List {
            Section {
                HStack {
                    Spacer()

                    VStack(spacing: 10) {
                        Image(systemName: "square.grid.2x2.fill")
                            .font(.system(size: 52))
                            .foregroundColor(.blue)

                        Text("機能図鑑")
                            .font(.title)
                            .fontWeight(.bold)

                        Text("SwiftUI の部品を試せるアプリ")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }

                    Spacer()
                }
                .padding(.vertical, 20)
            }

            Section(header: Text("アプリ情報")) {
                HStack {
                    Text("アプリ名")
                    Spacer()
                    Text("機能図鑑")
                        .foregroundColor(.secondary)
                }

                HStack {
                    Text("バージョン")
                    Spacer()
                    Text("1.0.0")
                        .foregroundColor(.secondary)
                }

                HStack {
                    Text("開発")
                    Spacer()
                    Text("自作")
                        .foregroundColor(.secondary)
                }
            }

            Section(header: Text("このアプリについて")) {
                Text("機能図鑑は、SwiftUI の部品を実際に操作しながら学ぶためのサンプルアプリです。")

                Text("Button、Toggle、Slider、TextField、Picker などの動作を確認できます。")
            }

            Section {
                HStack {
                    Spacer()

                    Text("機能図鑑 © 2026")
                        .font(.footnote)
                        .foregroundColor(.secondary)

                    Spacer()
                }
            }
        }
        .navigationBarTitle("このアプリについて")
    }
}
